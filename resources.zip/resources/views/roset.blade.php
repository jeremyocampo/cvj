
@extends('layouts.app')

@section('content')
@include('layouts.headers.inventoryCard1')
<div class="container-fluid mt--7">
	<div class="card-body">
		<div class="col-xl-8 mb-5 mb-xl-0">
				<div class="card shadow">
						<div class="card-header border-0">
								<div class="row align-items-center">
									<div class="col">
										<h3 class="mb-0">Rsoset Inventory Form</h3>
									</div>
								</div>
						</div>
						<div class="card-body border-0">
                        </div>
                </div></div>
	</div></div></div>


@endsection