<div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
    {{-- <div class="row">
        <div class="col-sm container-fluid">
            <div class="header-body">
                <!-- Card stats -->
                <div class="col-12">
                    <div class="">
                        <div class="card card-stats">
                            <a href="{{ url('inventory/create') }}">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-sm">
                                        <h3>Add Inventory</h3>
                                    </div>
                                    <div>
                                        <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                            <i class="fas fa-chart-bar"></i>
                                        </div>
                                    </div>
                                </div>    
                            </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm container-fluid">
                <div class="header-body">
                    <!-- Card stats -->
                    <div class="col-12">
                        <div class="">
                            <div class="card card-stats">
                                <a href="{{ url('inventory/create') }}">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm">
                                            <h3>Add Inventory</h3>
                                        </div>
                                        <div>
                                            <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                                <i class="fas fa-chart-bar"></i>
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm ontainer-fluid">
                    <div class="header-body">
                        <!-- Card stats -->
                        <div class="col-12">
                            <div class="">
                                <div class="card card-stats">
                                    <a href="{{ url('inventory/create') }}">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-sm">
                                                <h3>Add Inventory</h3>
                                            </div>
                                            <div>
                                                <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                                    <i class="fas fa-chart-bar"></i>
                                                </div>
                                            </div>
                                        </div>    
                                    </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div> --}}
    </div>