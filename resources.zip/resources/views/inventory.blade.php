@extends('layouts.app')

@include('layouts.headers.pagination')

@section('content')
    @include('layouts.headers.inventoryCard')

    <div class="container-fluid mt--7">
    	<div class="card-body">
            {{-- <div class="col-xl-8 mb-5 mb-xl-0"> --}}
            <div class="col-xl-12 mb-5">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="row">
                                <div class="col-xs-5">
                                    <h1 class="mb-0">Inventory</h1>
                                </div>
                                <div class="col-xs-4">
                                <a href="inventory/create" class="btn btn-sm btn-primary">+ Add Item</a>
                                </div>
                                </div>
                            </div>
                            <div class="col text-right">
                                {{-- <a href="inventory/create" class="btn btn-sm btn-primary">Add Item</a> --}}
                                
                            </div>
                            <div class="col text-left">
                                <input class="form-control" id="myInput" type="search" onkeyup="searchTable()" style="background: transparent;" placeholder="Search Item Here">
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <!-- Projects table -->
                        
                        <table class="table align-items-center table-flush" id="myTable">
                            <thead class="thead">
                                <tr>
                                    <th >Item name</th>
                                    <th >Category</th>
                                    <th >Quantity</th>
                                    <th >Barcode</th>
                                    <th >Last Modified (YY-MM-DD)</th>
                                    <th >Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($joinedInventory as $i)
			            		<tr>
								    <td>{{ $i->itemName }}</td>
								    <td>{{ $i->categoryName }}</td>
                                    <td>{{ $i->quantity }}</td>
                                    {{-- <td>{{ $i->barcode }}</td> --}}
                                    <td>{!! DNS1D::getBarcodeHTML($i->barcode, 'C128A') !!}</td>
                                    <td>{{ $i->last_modified }}</td>
                                    <td>
                                        <a class="btn btn-sm btn-primary" href="inventory/{{ $i->itemId }}/edit"> Replenish Item </a>
                                    </td>
								</tr>
								@endforeach
                            </tbody>
                            
                        </table>
                    <!--pagination-->
                    <div id="pageNavPosition" style="padding-top: 20px; cursor: pointer" align="center"></div>
                    <script type="text/javascript">
                        <!--
                        var pager = new Pager('myTable', 5);
                        pager.init();
                        pager.showPageNav('pager', 'pageNavPosition');
                        pager.showPage(1);
                    </script>
                    <!--pagination-->
                    </div>
                </div>
            </div>
        </div>
    @include('layouts.footers.auth')
    </div>
@endsection

@push('js')
    {{-- <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.min.js"></script>
    <script src="{{ asset('argon') }}/vendor/chart.js/dist/Chart.extension.js"></script> --}}
    <script>
        function searchTable() {
            // Declare variables 
            var input, filter, table, tr, td, i;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            th = table.getElementsByTagName("th");

            // Loop through all table rows, and hide those who don't match the search query
            for (i = 0; i <= tr.length; i++) {
                tr[i].style.display = "none";
                for (var j = 0; j <= th.length; j++) {
                    td = tr[i].getElementsByTagName("td")[j];
                    if (td) {
                        if (td.innerHTML.toUpperCase().indexOf(filter.toUpperCase()) > -1) {
                            tr[i].style.display = "";
                            break;
                        }
                    }
                }
            }
        }

    </script>


@endpush